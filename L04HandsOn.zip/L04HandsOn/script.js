class Employee {
    constructor(name, salary, hireDate) {
        this.name = name;
        this.salary = salary;
        this.hireDate = hireDate;
    }
    getName() {
        console.log(this.name.toUpperCase());
    }
    getSalary() {
        console.log(this.salary);
    }
    getHireDate() {
        console.log(this.hireDate);
    }
}
class Manager extends Employee {
    constructor(name, hireDate, salary, descriptionOfJob) {
        super(name, salary, hireDate)
        this.descriptionOfJob = descriptionOfJob;
    }
    jobDescription() {
        console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " because he " + this.descriptionOfJob);
    }
}
class Designer extends Employee {
    constructor(name, hireDate, salary, experience) {
        super(name, salary, hireDate)
        this.experience = experience;
    }
    yearsExperience() {
        console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " because she " + this.experience);
    }
}
class SalesAssociate extends Employee {
    constructor(name, hireDate, salary, degrees){
        super(name, salary, hireDate)
        this.degrees = degrees;
    }
    degreeCompleted() {
        console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " because he " + this.degrees);
    }
}
let ricky = new Manager("Ricky", "3/7/2018", "1,000,000,000", "manages the entire company.");
let kayla = new Designer("Kayla", "4/10/2018", "750,000", "worked with Michael Kors." );
let justin = new SalesAssociate("Justin", "6/8/2018", "250,000", "has 3 PhD's.");
ricky.jobDescription();
kayla.yearsExperience();
justin.degreeCompleted();