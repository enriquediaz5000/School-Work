function regexChecker() {
    firstName = document.getElementById("firstName").value;
    lastName = document.getElementById("lastName").value;
    let nameRegex = /^[A-Z][a-z]+/g;;
    if (firstName.match(nameRegex) && lastName.match(nameRegex)) {
        alert("Yay! Your inputs were all correct!");
        console.log(true);
        } else {
        alert ("Oh no! That's an invalid format!");
        console.log(false);
    }
 }