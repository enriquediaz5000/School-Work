const newRequest = new XMLHttpRequest();
newRequest.onreadystatechange = function() {
 if (this.readyState == 4 && this.status == 200) {
    let newObj = JSON.parse('{ "name": "Albert Einstein", "birthday": "03/14/1879"}');
    document.getElementById("example").innerHTML = newObj.name + ". Born on " + newObj.birthday;
 }
};
newRequest.open("GET", "einstein.json", true);
newRequest.send();
function loadBio(){
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        let thisBio = JSON.parse('{"bio": "Albert Einstein was a German-born theoretical physicist who developed the theory of relativity, one of the two pillars of modern physics. His work is also known for its influence on the philosophy of science."}')
        document.getElementById("bio").innerHTML = thisBio.bio;
      }
    };
    xhttp.open("GET", "einstein.json", true);
    xhttp.send();
}